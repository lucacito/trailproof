<?php

declare(strict_types=1);

namespace Trailproof;

use Trailproof\Admin\AdminBarToggle;
use Trailproof\Admin\AdminMenu;
use Trailproof\Admin\SettingsPage;
use Trailproof\Api\RestApi;
use Trailproof\Correction\CorrectionEngine;
use Trailproof\Correction\SitewideEnhancementsEngine;
use Trailproof\Cron\StaticScanScheduler;
use Trailproof\Notification\NotificationService;
use Trailproof\Repository\CorrectionRepository;
use Trailproof\Repository\IssueRepository;
use Trailproof\Scan\DiviEditorPrevention;

class Plugin {

	private static bool $initialized = false;

	public static function init(): void {
		if ( self::$initialized ) {
			return;
		}
		self::$initialized = true;

		$settings_page             = new SettingsPage();
		$admin_menu                = new AdminMenu( $settings_page );
		$rest_api                  = new RestApi();
		$admin_bar_toggle          = new AdminBarToggle();
		$scheduler                 = new StaticScanScheduler();
		$correction_engine         = new CorrectionEngine( new CorrectionRepository() );
		$sitewide_enhancements     = new SitewideEnhancementsEngine();
		$divi_prevention           = new DiviEditorPrevention();
		$notification_service      = new NotificationService( new IssueRepository() );

		// Cron hook + custom schedule must be registered on every load
		$scheduler->register();

		add_action( 'trailproof_scan_complete', [ $notification_service, 'on_scan_complete' ] );

		// Admin bar quick toggle (manage_options only)
		$admin_bar_toggle->register();

		// Render-time correction layer (non-destructive, output buffering)
		$correction_engine->register();

		// Sitewide CSS enhancements (focus indicators, touch targets, reduced motion)
		$sitewide_enhancements->register();

		// Divi 5 editor prevention — author-side nudges in the Visual Builder
		$divi_prevention->register();

		if ( is_admin() ) {
			add_action( 'admin_menu', [ $admin_menu, 'register_menus' ] );
			add_action( 'admin_enqueue_scripts', [ $admin_menu, 'enqueue_assets' ] );
			add_action( 'admin_init', [ $settings_page, 'register_settings' ] );

			// Re-sync the cron schedule whenever settings are saved
			add_action(
				'update_option_trailproof_settings',
				[ $scheduler, 'sync_schedule' ]
			);
		}

		add_action( 'rest_api_init', [ $rest_api, 'register_routes' ] );
	}
}
